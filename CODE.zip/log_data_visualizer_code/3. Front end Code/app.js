console.log('hitting');

const containerDiv = document.getElementById("vizContainer");
const url = 'https://public.tableau.com/views/LogDataSummaries/Dashboard1';
const options = {
}


function initViz() {
    let viz = new tableau.Viz(containerDiv, url, options);
}

document.addEventListener('DOMContentLoaded',initViz)